package service;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import vo.vo.VOUsuario;

@Path("/servicios")
public class ServiceLoginJR {

	@POST
	@Path("/validaUsuario")
	@Consumes({MediaType.APPLICATION_JSON})
	@Produces({MediaType.APPLICATION_JSON})
	public VOUsuario validaUsuario(VOUsuario usuario) {
		if(usuario.getUser().equals("Java") && usuario.getPassword().equals("pass")) {
			usuario.setUserValido(true);
		}
		return usuario;
		
	}
	
}
