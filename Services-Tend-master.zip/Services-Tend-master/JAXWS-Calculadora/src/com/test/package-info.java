@javax.xml.bind.annotation.XmlSchema(namespace = "http://test.com/")
package com.test;
