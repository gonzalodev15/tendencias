package com.test;

public class CalculadoraConsumer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CalculadoraImplService calculadoraservice = new CalculadoraImplService();
		Calculadora consumer = calculadoraservice.getCalculadoraImplPort();
		System.out.println("Suma");
		System.out.println(consumer.operacion(1, 6, 4));
		System.out.println("resta");
		System.out.println(consumer.operacion(2, 6, 4));
		
	}

}
